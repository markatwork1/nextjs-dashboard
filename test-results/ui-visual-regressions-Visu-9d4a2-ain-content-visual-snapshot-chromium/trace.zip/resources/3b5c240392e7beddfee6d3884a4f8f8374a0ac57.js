(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_7263c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_7263c3._.js",
  "chunks": [
    "static/chunks/_6075c0._.js"
  ],
  "source": "dynamic"
});
