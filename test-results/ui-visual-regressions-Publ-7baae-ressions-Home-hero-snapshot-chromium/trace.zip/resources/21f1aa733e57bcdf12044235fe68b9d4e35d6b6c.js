(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_7263c3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_7263c3._.js",
  "chunks": [
    "static/chunks/e2042_next_dist_5119df._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js",
    "static/chunks/app_ui_home_module_6dd21e.css"
  ],
  "source": "dynamic"
});
