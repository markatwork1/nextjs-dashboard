(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favicon_ico_mjs_841ff8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favicon_ico_mjs_841ff8._.js",
  "chunks": [
    "static/chunks/_634900._.js"
  ],
  "source": "dynamic"
});
