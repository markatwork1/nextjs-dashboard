(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_[id]_edit_page_tsx_33538e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_[id]_edit_page_tsx_33538e._.js",
  "chunks": [
    "static/chunks/_7f32da._.js"
  ],
  "source": "dynamic"
});
