(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/e2042_next_dist_compiled_react-dom_9759a0._.js",
    "static/chunks/e2042_next_dist_compiled_011061._.js",
    "static/chunks/e2042_next_dist_client_1b7ab8._.js",
    "static/chunks/e2042_next_dist_6fac98._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a8cd6b._.js"
  ],
  "source": "entry"
});
