(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_page_tsx_33538e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_page_tsx_33538e._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_e72b8c._.js",
    "static/chunks/app_fbd2c2._.js"
  ],
  "source": "dynamic"
});
