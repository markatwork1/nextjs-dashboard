(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_762b5b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_762b5b._.js",
  "chunks": [
    "static/chunks/app_ui_global_824c69.css",
    "static/chunks/app_layout_tsx_83fc40._.js"
  ],
  "source": "dynamic"
});
