(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_invoices_error_tsx_33538e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_invoices_error_tsx_33538e._.js",
  "chunks": [
    "static/chunks/app_dashboard_invoices_error_tsx_4d6687._.js"
  ],
  "source": "dynamic"
});
