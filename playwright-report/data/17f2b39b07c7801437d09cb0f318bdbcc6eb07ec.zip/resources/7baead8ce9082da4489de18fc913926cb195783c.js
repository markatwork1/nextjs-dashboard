(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_(overview)_page_tsx_33538e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_(overview)_page_tsx_33538e._.js",
  "chunks": [
    "static/chunks/e2042_next_dist_260017._.js",
    "static/chunks/app_dashboard_(overview)_page_tsx_31276a._.js"
  ],
  "source": "dynamic"
});
